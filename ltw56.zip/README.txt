Name of the group elements:

Pedro Jos� Louren�o Azevedo
Francisco Maria Fernandes Machado Santos
Bruno Miguel Faustino Moreno


Credentials needed to access the site:

User: pedro		Pass: 12345
User: francisMaria	Pass: PasswordAs173
user: bruno		Pass: 54321
<section id="intro">
    <h3>Make your every day life easier with Helpo.</h3>
    <img src="images/intro.jpg" height="80%" width="80%" alt="Intro Image."/>
</section>
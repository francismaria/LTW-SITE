<?php
/* 
* Copyright (C) LTW @ FEUP project authors. All rights reserved.
*
* Authors:
* - Bruno Miguel <@fe.up.pt>
* - Francisco <@fe.up.pt>
* - Pedro Azevedo   <up201306026@fe.up.pt>
*/
?>
 
    <footer>
      &copy; Bruno Miguel & Francisco & Pedro Azevedo // Copyright 2017 // LTW @ FEUP
    </footer>
    <script type="text/javascript" src="js/file.js"></script>
  </body>
</html>
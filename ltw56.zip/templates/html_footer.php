<?php
/* 
* Copyright (C) LTW @ FEUP project authors. All rights reserved.
*
* Authors:
* - Bruno Miguel <@up201504781fe.up.pt>
* - Francisco <@fe.up.pt>
* - Pedro Azevedo   <up201306026@fe.up.pt>
*/
?>

    <div id="footer">
      Bruno Miguel & Francisco & Pedro Azevedo // Copyright 2017 // LTW @ FEUP 
      <?echo '<div class="text dateheader">' . date('jS \of F Y h:i A') . '</div>'; ?>
    </div>
  </body>
</html>


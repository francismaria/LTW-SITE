<?php
  include_once('includes/session.php');
  /* include_once('database/connection.php'); */
?>